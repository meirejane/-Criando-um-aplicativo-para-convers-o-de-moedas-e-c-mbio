package br.com.dio.coinconverter.core.exceptions

class RemoteException(override val message: String) : Throwable()